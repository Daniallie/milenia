<!--- footer area --->
    <div class="container-fluid text-bg-primary text-warning align-items-center px-5 py-3">
        <div class="row">
            <div class="col-12 col-lg-6">
                <h3>
                    PT. MILENIA ARMADA EKSPRES
                </h3>
                <p>
                    Since 1999, MAX has connected businesses through logistics, and over the years, we are confident that we can help you and your business with logistics advice, and competitive rates in Indonesia.
                </p>

            </div>
            <div class="col-12 col-lg-2">

            </div>
            <div class="col-12 col-lg-4">
                <h3>
                    REACH US
                </h3>
                <p>    
                    Jl. Pakin Raya, Rukan Mitra Bahari
                    Blok A/15, Kel. Penjaringan Jakarta
                    Utara 14440 - Indonesia
                    <br>
                    Telp. +62 21 6602525
                    <br>
                    Instagram : @milenia
                </p>
                
            </div>
        </div>
        <div class="row text-dark">
            <div class="col-12 col-lg-6">
                Copyright © 2022 PT Milenia Armada Ekspres
            </div>
            <div class="col-12 col-lg-2"></div>
            <div class="col-12 col-lg-4">
                Powered by DuniaFreelancer.id
            </div>
        </div>
        <div class="row">
            <div class="col-12 col-lg-4"></div>
            <div class="col-12 col-lg-4"></div>
            <div class="col-12 col-lg-4"></div>
        </div>
    </div>
<!--- end footer ---><?php /**PATH C:\laragon\www\milenia\resources\views/partial/footer.blade.php ENDPATH**/ ?>