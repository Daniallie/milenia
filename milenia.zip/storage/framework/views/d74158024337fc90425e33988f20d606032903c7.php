<li><a href="/" class="nav-link px-2 text-warning">HOME</a></li>
<li><a href="about" class="nav-link px-2 text-white">OUR COMPANY</a></li>
<li><a href="services" class="nav-link px-2 text-white">OUR SERVICES</a></li><?php /**PATH C:\laragon\www\milenia\resources\views/partial/navbar.blade.php ENDPATH**/ ?>